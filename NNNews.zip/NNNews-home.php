<?php
  session_start();

  $con = mysqli_connect("localhost","root","root","nnnews");
  if(mysqli_connect_errno())
      die("Error while connecting to db: ". mysqli_connect_error());
?>

<html>
  <head>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
    <title> NNNews </title>
    <link rel="stylesheet" type="text/css" href="everything/NNNews - Style.css?ts=<?=time()?>" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
//---------------------------------------------------------------------------------

      window.setInterval("slideShow4()",3000);
      var i =2;
      function slideShow4(){
        if (i > 4) i=1;
        var pic = document.getElementById("slideImg4");
        pic.setAttribute("src","everything/"+i+".jpg");
        i++;
      }

      window.setInterval("disDate()",1000);
      function disDate(){
        var d = new Date();
          var n = d.toLocaleString();
          document.getElementById("datetime").innerHTML = n;
      }

      function menuBar() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
          x.className += " responsive";
        } else {
          x.className = "topnav";
        }
      }
//---------------------------------------------------------------------------------
    </script>
  </head>

  <body class="mainColor">
    <?php
    if(isset($_SESSION['userid'])){
      ?>
      <div class="signout">
        <ul> Welcome <?php echo $_SESSION['userid'] ?>
          <li> <a href="everything/Signout.php"> Sign out </a> </li>
        </ul>
      </div>
      <?php
    }
      else {
        ?>
        <div class="signin">
          <a href="everything/Signin.php"> Sign in </a>
        </div>
        <?php
      }
  ?>
    <header class="logoBack">
    <a href="NNNews-home.php"><img src="everything/logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
      <p style="display : inline;"> NNews </p>
      <p><em>New National News</em><p>
    </header>

    <div class="topnav" id="myTopnav">
      <a href="NNNews-home.php" class="active"> Home </a>
      <a href="everything/NNNews-education.php"> Education </a>
      <a href="everything/NNNews-technology.php"> Technology </a>
      <a href="everything/NNNews-travel.php"> Travel </a>
      <a href="everything/NNNews-sport.php"> Sport </a>

      <?php
        if(isset($_SESSION['userid'])){ // if #1
          $uid = $_SESSION['userid'];
          $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
          $res = mysqli_query($con, $Qsel);
          $ro = null;
          if(mysqli_num_rows($res)==1){
            while($row = mysqli_fetch_assoc($res)){
              $ro = $row['role'];
            }
          }
          if($ro == "Journalist"){
            ?>
            <div class="dropdown">
              <button class="dropbtn">Menu</button>
              <div class="dropdown-content" id="myDropdown">
                <a href="everything/JNewArticle.php"> New Article </a>
                <a href="everything/JDraft.php"> Draft </a>
                <a href="everything/JMail.php"> Mail </a>
                <a href="everything/JPublishedArticles.php"> Published Articles </a>
              </div>
            </div>
            <?php
          }
          if($ro == "Editor"){
            ?>
              <a href="everything/EPendingArticles.php"> Pending Articles </a>
            <?php
          }
          if($ro == "Administrator"){
            ?>
              <a href="everything/AManageAccounts.php"> Manage Accounts </a>
            <?php
          }
        } // if #1
        ?>
        <a href="javascript:void(0);" style="font-size:15pt;" class="icon" onclick="menuBar()">&#9776;</a>
    </div>


    <section id="mainPhoto" class="slideShow">
      <img id="slideImg4" src="everything/1.jpg">
    </section>

    <section id="hotNews" class="hotNews">
      <h1> <em> Hot News </em> </h1>

    <?php
      $query = " SELECT * FROM articles WHERE status = 2 ORDER BY article_id DESC LIMIT 4";
      $result = mysqli_query($con,$query);
      $i = 0;
      while($row = mysqli_fetch_array($result)){
        $i++;
        if($i%2){
        ?>
        <article class="odd">
          <img src="everything/<?php echo $row['attachment']; ?>" >
          <h1> <?php echo $row['title']; ?> </h1>
          <a href="everything/ViewNews.php?id=<?php echo $row['article_id']; ?>" style="color : white; font-weight: bold; float: right;"> More Information </a>
        </article>
        <?php
        } else {
          ?>
          <article class="even">
            <img src="everything/<?php echo $row['attachment']; ?>" >
            <h1> <?php echo $row['title']; ?> </h1>
            <a href="everything/ViewNews.php?id=<?php echo $row['article_id']; ?>" style="color : white; font-weight: bold; float: right;"> More Information </a>
          </article>
        <?php
        }
      }
      ?>

    </section>

    <section id="news" class="news">
      <h1> <em> News </em> </h1>
      <article id="ar1" class="first">
        <img src="everything/travel/tr1.jpg" >
        <h1> London hotel suite on sale for $14 million </h1>
        <p>
          (CNN) — Got a spare $14 million lying around that you're wondering what to do with?
          If you're in the market for a new luxury pad, you could splash the cash on a 3,703 square
          foot hotel suite at 10 Whitehall Place, adjacent to the five-star Corinthia Hotel in London.
        </p>
        <a href="everything/travel/Travel1.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar2" class="first">
        <img src="everything/travel/tr2.jpg" >
        <h1> Flight Passengers Were Stranded for Days in Freezing Siberia </h1>
        <p>
          Passengers on an Air France flight traveling from Paris to Shanghai were left
          stranded in freezing Siberia for three days this week after their plane was forced
          to make an emergency landing and their replacement plane suffered a technical issue.
        </p>
        <a href="everything/travel/Travel2.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar3" class="first">
        <img src="everything/technology/te1.jpg" >
        <h1> Whether Intended or Accidental, Internet Traffic Rerouting Can Be Costly </h1>
        <p>
          An apparent prefix leak from an errant router misconfiguration caused Google to
          lose control of several million of its IP addresses for more than an hour on Monday.
        </p>
        <a href="everything/technology/Technology1.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar4" class="second">
        <img src="everything/technology/te2.jpg" >
        <h1> Google Shows Off New Android Dev Tools </h1>
        <p>
          Google has announced support for a range of new Android tools for application developers,
          chief among them the creation of a new support category for foldable devices.
        </p>
        <a href="everything/technology/Technology2.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar5" class="first">
        <img src="everything/sport/sp3.jpg" >
        <h1> Making it in Germany </h1>
        <p>
          Pulisic's journey to the top of the game has been a tough one. It's also been an unusual one.
          The attacking midfielder moved to Germany to join Borussia Dortmund's youth academy in 2015 and, just a year later, made is first-team debut.
        </p>
        <a href="everything/sport/Sport3.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar6" class="first">
        <img src="everything/sport/sp4.jpg" >
        <h1> A need for speed </h1>
        <p>
          Lips turning blue, they shiver in ice baths, unable to escape. Only the cooperation of teammates solving mental puzzles and completing physical
          challenges can release them from the water's frozen grip.
        </p>
        <a href="everything/sport/Sport4.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar7" class="first">
        <img src="everything/education/ed1.jpg" >
        <h1> CCIS Practical Training Day </h1>
        <p>
          An apparent prefix leak from an errant router misconfiguration caused Google to
          lose control of several million of its IP addresses for more than an hour on Monday.
        </p>
        <a href="everything/education/Education1.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar8" class="first">
        <img src="everything/education/ed2.jpg" >
        <h1> “Hackathon Arabia”: a youth competition for developing applications and games at the college of Computer and Information Sciences </h1>
        <p>
          Hackathon Arabia is a tech competition that many tech enthusiasts participate in,
          from developers to designers and individuals talented in developing and
          designing applications, games and VR technologies
        </p>
        <a href="everything/education/Education2.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
    </section>

    <?php
      require 'Footer.php';
    ?>
