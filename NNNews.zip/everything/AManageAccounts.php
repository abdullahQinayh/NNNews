
 <?php
   session_start();

   $con = mysqli_connect("localhost","root","root","nnnews");
   if(mysqli_connect_errno())
       die("Error while connecting to db: ". mysqli_connect_error());
 ?>

 <html>
   <head>
     <meta charset="utf-8">
     <title> NNNews </title>
     <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
     <link rel="stylesheet" type="text/css" href="NNNews - Style.css?ts=<?=time()?>" />
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script>
 //---------------------------------------------------------------------------------
       $(document).ready(function(){
         $('#confirm_password').on('keyup', validate);
         $('#password').on('keyup', validate);
         $('#confirm_password2').on('keyup', validate2);
         $('#password2').on('keyup', validate2);

         // add confirmation
         function validate(){
           if ($('#password').val() === $('#confirm_password').val()) {
             $("#addUser").removeAttr("disabled");
             $("#notConfirmed").html("");
           } else {
             $("#addUser").attr("disabled","disabled");
             $("#notConfirmed").html("Please confirm your password");
           }
         }
         // edit confirmation
         function validate2(){
           if ($('#password2').val() === $('#confirm_password2').val()) {
             $("#editUser").removeAttr("disabled");
             $("#notConfirmed2").html("");
           } else {
             $("#editUser").attr("disabled","disabled");
             $("#notConfirmed2").html("Please confirm your password");
           }
         }

         $("input").focus(function () {
           $("#message").html("");
         });

       });

       window.setInterval("disDate()",1000);
       function disDate(){
           var d = new Date();
           var n = d.toLocaleString();
           document.getElementById("datetime").innerHTML = n;
       }

       function menuBar() {
         var x = document.getElementById("myTopnav");
         if (x.className === "topnav") {
           x.className += " responsive";
         } else {
           x.className = "topnav";
         }
       }
 //---------------------------------------------------------------------------------
     </script>
   </head>

   <body class="mainColor">
     <?php
     if(isset($_SESSION['userid'])){
       ?>
       <div class="signout">
         <ul> Welcome <?php echo $_SESSION['userid'] ?>
           <li> <a href="Signout.php"> Sign out </a> </li>
         </ul>
       </div>
       <?php
     }
       else {
         ?>
         <div class="signin">
           <a href="Signin.php"> Sign in </a>
         </div>
         <?php
       }
   ?>
     <header class="logoBack">
     <a href="../NNNews-home.php"><img src="logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
       <p style="display : inline;"> NNews </p>
       <p><em>New National News</em><p>
     </header>

     <div class="topnav" id="myTopnav">
       <a href="../NNNews-home.php"> Home </a>
       <a href="NNNews-education.php"> Education </a>
       <a href="NNNews-technology.php"> Technology </a>
       <a href="NNNews-travel.php"> Travel </a>
       <a href="NNNews-sport.php"> Sport </a>

       <?php
         if(isset($_SESSION['userid'])){ // if #1
           $uid = $_SESSION['userid'];
           $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
           $res = mysqli_query($con, $Qsel);
           $ro = null;
           if(mysqli_num_rows($res)==1){
             while($row = mysqli_fetch_assoc($res)){
               $ro = $row['role'];
             }
           }
           if($ro == "Journalist"){
             ?>
             <div class="dropdown">
               <button class="dropbtn">Menu</button>
               <div class="dropdown-content" id="myDropdown">
                 <a href="JNewArticle.php"> New Article </a>
                 <a href="JDraft.php"> Draft </a>
                 <a href="JMail.php"> Mail </a>
                 <a href="JPublishedArticles.php"> Published Articles </a>
               </div>
             </div>
             <?php
           }
           if($ro == "Editor"){
             ?>
               <a href="EPendingArticles.php" class="active"> Pending Articles </a>
             <?php
           }
           if($ro == "Administrator"){
             ?>
               <a href="AManageAccounts.php"> Manage Accounts </a>
             <?php
           }
         } // if #1
         ?>
         <a href="javascript:void(0);" style="font-size:15pt;" class="icon" onclick="menuBar()">&#9776;</a>
     </div>


     <div style="margin : 2% 4%; overflow:hidden;" >

       <form action="AddUser.php" method="post">
         <div class="form-row align-items-center" style="margin-left:8%;">
           <div class="col-sm-3 my-1">
             <input type="text" class="form-control" id="inlineFormInputName" name="UName" placeholder="Username" required>
           </div>
           <div class="col-sm-3 my-1">
               <input type="password" class="form-control" id="password" name="PWD" placeholder="Password" required>
           </div>
           <div class="col-sm-3 my-1">
               <input type="password" class="form-control" id="confirm_password" placeholder="Confirm Password" required>
           </div>
             <div class="form-check">
               <Select class="custom-select" name="ROLE" required>
                 <option value="" name="ROLE" > select role
                 <option value="Journalist" name="ROLE" > Journalist
                 <option value="Editor" name="ROLE" > Editor
               </Select>
             </div>
             <button type="submit" class="btn btn-primary" id="addUser" disabled>Add user</button>
         </div>
       </form>

       <?php
       if(isset($_GET['error'])){
           echo("<div class='error-text' id='message'>".$_GET['error']."</div>");
       } else if(isset($_GET['success'])){
           echo("<div class='success-text' id='message'>".$_GET['success']."</div>");
       }
       ?>

       <div class='error-text' id='notConfirmed'> </div>

       <h2> Jornalists: </h2>
       <h2 style="margin-left: 46.5%; margin-top: -2.7%; position:absolute;"> Editors: </h2>

 <!-- Journalist Table   //////////////////////////////////////// -->
       <div class="table-responsive" style="display: inline-block; width: 49%; float:left;">
       <table class="table table-striped table-bordered table-hover" >
         <thead><tr>
           <th class="num-col"> # </th>
           <th> Username </th>
           <th> Password </th>
           <th> Role </th>
           <th class="btn-col">Action</th>
         </tr></thead>
         <tbody>
         <?php
           $query = " SELECT * FROM users WHERE role <> 'Administrator' AND role <> 'Editor' ";
           $result = mysqli_query($con,$query);
           $i = 0;
           while($row = mysqli_fetch_array($result)){
             $i++;
             ?>
             <tr class="odd gradeX">
               <td class="num-col"> <?php echo $i; ?> </td>
               <td> <?php echo $row['username']; ?> <input type="text" size="10" id="newName" class="hidden" value="<?php echo $row['username']; ?>"> </td>
               <td> <?php echo $row['password']; ?> <input type="text" size="10" id="newPass" class="hidden" value="<?php echo $row['password']; ?>"> </td>
               <td> <?php echo $row['role']; ?> <input type="text" size="10" id="newRole" class="hidden" value="<?php echo $row['role']; ?>"> </td>
               <input type="text" id="Uid" class="hidden" value="<?php echo $row['user_id']; ?>">

               <td class="btn-col-sm-i-2">
                 <a href="<?php  echo "?editing=".$row['user_id']."&name=".$row['username']."&pass=".$row['password']."&role=".$row['role'] ?>"> <button name="edit" class="btn btn-primary" id="edit"> <i class="small material-icons">edit</i> </button> </a>
                 <a id="delete" href="ADeleteUser.php?<?php  echo "user=".$row['username']; ?>"><button onclick="return confirm('Are you sure you want to delete this user?')" class="btn btn-primary"> <i class="small material-icons">delete</i> </button></a>

               </td>
             </tr>
             <?php
           } ?>
         </tbody>
       </table>
     </div>

 <!-- Editor Table   //////////////////////////////////////// -->
 <div class="table-responsive" style="display: inline-block; width: 49%; float: right; margin-left:1%;">
 <table class="table table-striped table-bordered table-hover" >
   <thead><tr>
     <th class="num-col"> # </th>
     <th> Username </th>
     <th> Password </th>
     <th> Role </th>
     <th class="btn-col">Action</th>
   </tr></thead>
   <tbody>
   <?php
     $query = " SELECT * FROM users WHERE role = 'Editor' ";
     $result = mysqli_query($con,$query);
     $i = 0;
     while($row = mysqli_fetch_array($result)){
       $i++;
       ?>
       <tr class="odd gradeX">
         <td class="num-col"> <?php echo $i; ?> </td>
         <td> <?php echo $row['username']; ?> <input type="text" size="10" id="newName" class="hidden" value="<?php echo $row['username']; ?>"> </td>
         <td> <?php echo $row['password']; ?> <input type="text" size="10" id="newPass" class="hidden" value="<?php echo $row['password']; ?>"> </td>
         <td> <?php echo $row['role']; ?> <input type="text" size="10" id="newRole" class="hidden" value="<?php echo $row['role']; ?>"> </td>
         <input type="text" id="Uid" class="hidden" value="<?php echo $row['user_id']; ?>">

         <td class="btn-col-sm-i-2">
           <a href="<?php  echo "?editing=".$row['user_id']."&name=".$row['username']."&pass=".$row['password']."&role=".$row['role'] ?>"> <button name="edit" class="btn btn-primary" id="edit"> <i class="small material-icons">edit</i> </button> </a>
           <a id="delete" href="ADeleteUser.php?<?php  echo "user=".$row['username']; ?>"><button onclick="return confirm('Are you sure you want to delete this user?')" class="btn btn-primary"> <i class="small material-icons">delete</i> </button></a>

         </td>
       </tr>
       <?php
     } ?>
   </tbody>
 </table>
</div>

   </div>


    <?php if(isset($_GET['editing'])) {
       echo '<form action="AEditUser.php" method="post">
               <div class="form-row align-items-center" style="margin-left:8%;">
                 <div class="col-sm-3 my-1">
                   <input type="text" class="form-control" id="inlineFormInputName" name="UName" value="' .$_GET['name']. '" placeholder="NEW USERNAME" required>
                 </div>
                 <div class="col-sm-3 my-1">
                   <input type="password" class="form-control" id="password2" name="Pass"  placeholder="NEW PASSWORD" required>
                 </div>
                 <div class="col-sm-3 my-1">
                   <input type="password" class="form-control" id="confirm_password2" placeholder="Confirm Password" required>
                 </div>
                 <div class="form-check">
                   <Select class="custom-select" name="Role" value="' .$_GET['role']. '" required>
                     <option value="" name="ROLE" > select role
                     <option value="Journalist" name="ROLE" > Journalist
                     <option value="Editor" name="ROLE" > Editor
                   </Select>
                   <input type="hidden" name="editing" value="' .$_GET['editing']. '">
                 </div>
                 <button type="submit" class="btn btn-primary" id="editUser" >Edit</button>
               </div>
             </form>';
    }
     ?>
     <div class='error-text' id='notConfirmed2'> </div>

   <div class="divide">
   </div>

     <?php
       require 'Footer.php';
     ?>
