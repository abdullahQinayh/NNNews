<?php

  $con = mysqli_connect("localhost","root","root","NNNews");
  $id = $_GET['id'];
  $query = " DELETE FROM articles WHERE article_id = '".$id."' ";
  $result = mysqli_query($con,$query);

  if($result){
    header('Location:JDraft.php?success=ARTICLE DELETED SUCCESSFULLY!');
  } else {
    header('Location:JDraft.php?error=ERROR DELETING ARTICLE!');
  }




?>
