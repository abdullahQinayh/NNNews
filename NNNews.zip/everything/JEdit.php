<?php

    session_start();
    $con = mysqli_connect("localhost","root","root","nnnews");

    if(isset($_POST['cancel'])){
      header('Location:JDraft.php?error=EDITING CANCELLED!');
      die();
    }

    $id = $_POST['ID'];
    $user = $_SESSION['userid'];
    $title = $_POST['TITLE'];
    $content = $_POST['CONTENT'];
    $date = date("Y-m-d");

    $target_dir = "uploads/";
    $filename = basename($_FILES['PIC']['name']);
    $target = $target_dir . basename($_FILES['PIC']['name']);
    if(move_uploaded_file($_FILES["PIC"]["tmp_name"],$target)){

    $query = " UPDATE articles SET title = '".$title."', content = '".$content."', username = '".$user."', da = '".$date."', attachment = '".$target."' WHERE article_id= '".$id."' ";

    $result = mysqli_query($con,$query);

    if($result){
      header('Location:JDraft.php?success=EDITED SUCCESSFULLY!');
      //header('Location:JDraft.php?success=EDITED SUCCESSFULLY!');
    } else {
      header('Location:JDraft.php?error=ERROR EDITING!');
    }

} else {
  echo "ERROR";
}

?>
