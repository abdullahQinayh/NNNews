<?php

    session_start();
    $con = mysqli_connect("localhost","root","root","nnnews");

    $com = $_POST['comment'];
    $title = $_POST['title'];
    $jour = $_POST['jour'];
    $id = $_POST['Aid'];
    $date = date("Y-m-d");

    $query = " INSERT INTO comments (title,article_id,username,comment,da) VALUES ('".$title."','".$id."','".$jour."','".$com."','".$date."') ";

    $result = mysqli_query($con,$query);

    if($result){
      header('Location:EPendingArticles.php?success=COMMENT SENT SUCCESSFULLY!');
    } else {
      header('Location:EPendingArticles.php?error=ERROR SENDING COMMENT!');
    }



?>
