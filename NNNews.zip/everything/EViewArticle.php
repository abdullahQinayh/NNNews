<?php
  session_start();

  $con = mysqli_connect("localhost","root","root","nnnews");
  if(mysqli_connect_errno())
      die("Error while connecting to db: ". mysqli_connect_error());
?>

<html>
  <head>
    <meta charset="utf-8">
    <title> NNNews </title>
    <link rel="stylesheet" type="text/css" href="NNNews - Style.css?ts=<?=time()?>" />
  <!--  <link href="EditedBootstrap.css" rel="stylesheet" type="text/css">  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
//---------------------------------------------------------------------------------

      $(document).ready(function(){
        validate();
        $('#commentIn').on('keyup', validate);
        function validate(){
          if ($('#commentIn').val().length === 0) {
              $("#com").attr("disabled","disabled");
          } else {
              $("#com").removeAttr("disabled");
          }
        }
      });

      window.setInterval("disDate()",1000);
      function disDate(){
          var d = new Date();
          var n = d.toLocaleString();
          document.getElementById("datetime").innerHTML = n;
      }

      function menuBar() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
          x.className += " responsive";
        } else {
          x.className = "topnav";
        }
      }
//---------------------------------------------------------------------------------
    </script>
  </head>

  <body class="mainColor">
    <?php
    if(isset($_SESSION['userid'])){
      ?>
      <div class="signout">
        <ul> Welcome <?php echo $_SESSION['userid'] ?>
          <li> <a href="Signout.php"> Sign out </a> </li>
        </ul>
      </div>
      <?php
    }
      else {
        ?>
        <div class="signin">
          <a href="Signin.php"> Sign in </a>
        </div>
        <?php
      }
  ?>
    <header class="logoBack">
    <a href="../NNNews-home.php"><img src="logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
      <p style="display : inline;"> NNews </p>
      <p><em>New National News</em><p>
    </header>

    <div class="topnav" id="myTopnav">
      <a href="../NNNews-home.php"> Home </a>
      <a href="NNNews-education.php"> Education </a>
      <a href="NNNews-technology.php"> Technology </a>
      <a href="NNNews-travel.php"> Travel </a>
      <a href="NNNews-sport.php"> Sport </a>

      <?php
        if(isset($_SESSION['userid'])){ // if #1
          $uid = $_SESSION['userid'];
          $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
          $res = mysqli_query($con, $Qsel);
          $ro = null;
          if(mysqli_num_rows($res)==1){
            while($row = mysqli_fetch_assoc($res)){
              $ro = $row['role'];
            }
          }
          if($ro == "Journalist"){
            ?>
            <div class="dropdown">
              <button class="dropbtn">Menu</button>
              <div class="dropdown-content" id="myDropdown">
                <a href="JNewArticle.php"> New Article </a>
                <a href="JDraft.php"> Draft </a>
                <a href="JMail.php"> Mail </a>
                <a href="JPublishedArticles.php"> Published Articles </a>
              </div>
            </div>
            <?php
          }
          if($ro == "Editor"){
            ?>
              <a href="EPendingArticles.php" class="active"> Pending Articles </a>
            <?php
          }
          if($ro == "Administrator"){
            ?>
              <a href="AManageAccounts.php"> Manage Accounts </a>
            <?php
          }
        } // if #1
        ?>
        <a href="javascript:void(0);" style="font-size:15pt;" class="icon" onclick="menuBar()">&#9776;</a>
    </div>


    <div style="margin : 2% 4%;" >

      <?php
      if(isset($_GET['error'])){
          echo("<div class='error-text' id='message'>".$_GET['error']."</div>");
      } else if(isset($_GET['success'])){
          echo("<div class='success-text' id='message'>".$_GET['success']."</div>");
      }
      ?>

      <div class="table-responsive">
      <table class="table table-striped table-bordered table-hover" >

        <tbody>
          <?php
          $id = $_GET['id'];
          $Asele = "SELECT * FROM articles WHERE article_id = '".$id."'";
          $result = mysqli_query($con, $Asele);
          while($row = mysqli_fetch_array($result)){
          ?>

              <tr class="odd gradeX">
                <td class="title-col"> Journalist </td>
                <td> <?php echo $row['username']; ?> </td>
              </tr>
              <tr>
                <td class="title-col"> Title </td>
                <td> <?php echo $row['title']; ?> </td>
              </tr>
              <tr>
                <td class="title-col"> Content </td>
                <td> <?php echo $row['content']; ?> </td>
              </tr>
              <tr>
                <td class="title-col"> Image </td>
                <td class="img-col"> <img src="<?php echo $row['attachment']; ?>" alt="<?php echo $row['attachment']; ?>"> </td>
              </tr>
              <tr>
                <td class="title-col"> Date </td>
                <td> <?php echo $row['da']; ?> </td>
              </tr>
              <tr>

              </tr>
              <?php
            }
              ?>
        </tbody>
      </table>
      <div>
        <?php
        $id = $_GET['id'];
        $Asele = "SELECT * FROM articles WHERE article_id = '".$id."'";
        $result = mysqli_query($con, $Asele);
        while($row = mysqli_fetch_array($result)){
          ?>
          <a class="btn-align-2" href="EPostArticle.php?<?php  echo "id=".$row['article_id']; ?>"><button class="btn btn-primary"> Post </button></a>
          <a href="EDeleteArticle.php?<?php  echo "id=".$row['article_id']; ?>"><button onclick="return confirm('Are you sure you want to delete this article?')" class="btn btn-primary"> Delete </button></a>
          <?php
        }
        ?>
      </div>
    </div>
    <form class="form-row align-items-center" action="EComment.php" method="post">
      <?php
      $id = $_GET['id'];
      $Asele = "SELECT * FROM articles WHERE article_id = '".$id."'";
      $result = mysqli_query($con, $Asele);
      while($row = mysqli_fetch_array($result)){
      ?>
      <input type="text" class="hidden" name="title" value="<?php echo $row['title']; ?>">
      <input type="text" class="hidden" name="jour" value="<?php echo $row['username']; ?>">
      <input type="text" class="hidden" name="Aid" value="<?php echo $row['article_id']; ?>">
      <div class="col-2 my-1">
        <textarea class="form-control" id="commentIn" name="comment" placeholder="Comment" rows="3"></textarea>
      </div>
      <button id="com" type="submit" class="btn btn-primary" disabled> Comment </button>
      <?php
    }
      ?>
    </form>
  </div>

  <div class="divide">
  </div>

    <?php
      require 'Footer.php';
    ?>
