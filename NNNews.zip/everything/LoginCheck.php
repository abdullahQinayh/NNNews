<?php
	session_start();

	$con = mysqli_connect("localhost","root","root","nnnews");
	if(mysqli_connect_errno())
		die("DB connection failed".mysqli_connect_error());

	$user = $_POST['UName'];
	$pass = $_POST['PWD'];
	$role = $_POST['ROLE'];

	$query = "SELECT * FROM  users WHERE username='".$user."' AND password='".$pass."' AND role='".$role."' ";

	$result = mysqli_query($con, $query);

	if(mysqli_num_rows($result) > 0){
		while($row = mysqli_fetch_assoc($result))
			$_SESSION['userid'] = $row['username'];
		header('Location:../NNNews-home.php');
	} else {
		header('Location:signin.php?error=Wrong username or password or role!');
	}


?>
