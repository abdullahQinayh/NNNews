<?php

    session_start();
    $con = mysqli_connect("localhost","root","root","nnnews");

    $id = $_POST['editing'];
    $name = addslashes($_POST['UName']);
    $pass = addslashes($_POST['Pass']);
    $role = $_POST['Role'];

    $query = " UPDATE users SET username = '".$name."', password = '".$pass."', role = '".$role."' WHERE user_id= '".$id."' ";

    $result = mysqli_query($con,$query);

    if($result){
      header('Location:AManageAccounts.php?success=USER EDITED SUCCESSFULLY!');
    } else {
      header('Location:AManageAccounts.php?error=ERROR EDITING USER!');
    }



?>
