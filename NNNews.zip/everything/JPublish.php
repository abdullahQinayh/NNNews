<?php

    session_start();

    if(isset($_POST['Publish'])){
      $user = $_SESSION['userid'];
      $title = $_POST['TITLE'];
      $content = $_POST['CONTENT'];
      $date = date("Y-m-d");
      $target_dir = "uploads/";
      $filename = basename($_FILES['PIC']['name']);
      $target = $target_dir . basename($_FILES['PIC']['name']);
      if(move_uploaded_file($_FILES["PIC"]["tmp_name"],$target)){
        $con = mysqli_connect("localhost","root","root","nnnews");
        if(isset($_POST['Publish'])){
          $query = "INSERT INTO articles (username,title,content,attachment,da,status) VALUES ('".$user."','".$title."','".$content."','".$target."','".$date."',1)" ;
          $result = mysqli_query($con,$query);
          if($result){
            header('Location:JNewArticle.php?success=ARTICLE PUBLISHED SUCCESSFULLY!');
          } else {
            header('Location:JNewArticle.php?error=ERROR PUBLISHING ARTICLE!');
          }
        }
      }
    }
    else if(isset($_POST['Draft'])){
      $user = $_SESSION['userid'];
      $title = $_POST['TITLE'];
      $content = $_POST['CONTENT'];
      $date = date("Y-m-d");
      $target_dir = "uploads/";
      $filename = basename($_FILES['PIC']['name']);
      $target = $target_dir . basename($_FILES['PIC']['name']);
      if(move_uploaded_file($_FILES["PIC"]["tmp_name"],$target)){
        $con = mysqli_connect("localhost","root","root","nnnews");
        if(isset($_POST['Draft'])){
          $query = "INSERT INTO articles (username,title,content,attachment,da,status) VALUES ('".$user."','".$title."','".$content."','".$target."','".$date."',0)" ;
          $result = mysqli_query($con,$query);
          if($result){
            header('Location:JNewArticle.php?success=ARTICLE SENT TO DRAFT SUCCESSFULLY!');
          } else {
            header('Location:JNewArticle.php?error=ERROR SENDING ARTICLE TO DRAFT!');
          }
        }
      }
    }
    else {
    $con = mysqli_connect("localhost","root","root","nnnews");
//    $query = " SELECT * FROM articles WHERE article_id = '".$_GET['id']."' ";
//    $result = mysqli_query($con,$query);
//    $row = mysqli_fetch_array($result);
//      $user = $row['username'];
//      $title = $row['title'];
//      $date = date("Y-m-d");
//      $content = $row['content'];
//      $target = $row['attachment'];


      $query = " UPDATE articles SET status = 1 WHERE article_id = '".$_GET['id']."' ";
      $result = mysqli_query($con,$query);
      if($result){
        header('Location:JDraft.php?success=ARTICLE PUBLISHED SUCCESSFULLY!');
      } else {
        header('Location:JDraft.php?error=ERROR PUBLISHING ARTICLE!');
      }




}



?>
