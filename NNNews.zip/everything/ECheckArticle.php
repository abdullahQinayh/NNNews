<?php

  $con = mysqli_connect("localhost","root","root","NNNews");
  $id = $_GET['id'];
  $query = " SELECT FROM articles WHERE article_id = '".$id."' ";
  $result = mysqli_query($con,$query);

  if($result){
    header('Location:EViewArticle.php?id='".$id."' ');
  } else {
    header('Location:EPendingArticles.php?error=ERROR VIEWING ARTICLE!');
  }
?>
