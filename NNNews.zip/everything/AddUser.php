<?php

    session_start();
    $con = mysqli_connect("localhost","root","root","nnnews");

    $name = addslashes($_POST['UName']);
    $pass = addslashes($_POST['PWD']);
    $role = $_POST['ROLE'];

    $query = " INSERT INTO users (username,password,role) VALUES ('".$name."','".$pass."','".$role."') ";

    $result = mysqli_query($con,$query);

    if($result){
      header('Location:AManageAccounts.php?success=USER ADDED SUCCESSFULLY!');
    } else {
      header('Location:AManageAccounts.php?error=ERROR ADDING USER!');
    }



?>
