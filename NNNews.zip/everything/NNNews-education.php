<?php
  session_start();

  $con = mysqli_connect("localhost","root","root","nnnews");
  if(mysqli_connect_errno())
      die("Error while connecting to db: ". mysqli_connect_error());
?>

<html>
  <head>
    <meta charset="utf-8">
    <title> NNNews - Education </title>

    <link rel="stylesheet" type="text/css" href="NNNews - Style.css?'ts=<?=time()?>'" />

    <script>
//---------------------------------------------------------------------------------
      window.setInterval("slideShow4()",3000);
      var i =2;
      function slideShow4(){
        if (i > 5) i=1;
        var pic = document.getElementById("slideImg");
        pic.setAttribute("src","education/ed"+i+".jpg");
        i++;
      }

      window.setInterval("disDate()",1000);
      function disDate(){
        var d = new Date();
          var n = d.toLocaleString();
          document.getElementById("datetime").innerHTML = n;
      }

      function menuBar() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
          x.className += " responsive";
        } else {
          x.className = "topnav";
        }
      }
//---------------------------------------------------------------------------------
    </script>

  </head>

  <body class="mainColor">
    <?php
    if(isset($_SESSION['userid'])){
      ?>
      <div class="signout">
        <ul> Welcome <?php echo $_SESSION['userid'] ?>
          <li> <a href="Signout.php"> Sign out </a> </li>
        </ul>
      </div>
      <?php
    }
      else {
        ?>
        <div class="signin">
          <a href="Signin.php"> Sign in </a>
        </div>
        <?php
      }
  ?>
    <header class="logoBack">
    <a href="../NNNews-home.php"><img src="logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
      <p style="display : inline;"> NNews </p>
      <p><em>New National News</em><p>
    </header>

    <div class="topnav" id="myTopnav">
      <a href="../NNNews-home.php"> Home </a>
      <a href="NNNews-education.php" class="active"> Education </a>
      <a href="NNNews-technology.php"> Technology </a>
      <a href="NNNews-travel.php"> Travel </a>
      <a href="NNNews-sport.php"> Sport </a>

      <?php
        if(isset($_SESSION['userid'])){ // if #1
          $uid = $_SESSION['userid'];
          $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
          $res = mysqli_query($con, $Qsel);
          $ro = null;
          if(mysqli_num_rows($res)==1){
            while($row = mysqli_fetch_assoc($res)){
              $ro = $row['role'];
            }
          }
          if($ro == "Journalist"){
            ?>
            <div class="dropdown">
              <button class="dropbtn">Menu</button>
              <div class="dropdown-content" id="myDropdown">
                <a href="JNewArticle.php"> New Article </a>
                <a href="JDraft.php"> Draft </a>
                <a href="JMail.php"> Mail </a>
                <a href="JPublishedArticles.php"> Published Articles </a>
              </div>
            </div>
            <?php
          }
          if($ro == "Editor"){
            ?>
              <a href="EPendingArticles.php"> Pending Articles </a>
            <?php
          }
          if($ro == "Administrator"){
            ?>
              <a href="AManageAccounts.php"> Manage Accounts </a>
            <?php
          }
        } // if #1
        ?>
        <a href="javascript:void(0);" style="font-size:15pt;" class="icon" onclick="menuBar()">&#9776;</a>
    </div>


    <section id="mainPhoto" class="slideShow">
      <img id="slideImg" src="education/ed1.jpg">
    </section>


        <section id="news-edu" class="news-edu">
          <h1 > <em> Education </em> </h1>
          <article id="ar1" class="first">
            <img src="education/ed1.jpg" >
            <h1> CCIS Practical Training Day </h1>
            <p>
              The Practical Training Committee at the College of Computer and Information Sciences (CCIS) at King Saud University organized the "CCIS Practical
              Training Day" and its accompanying exhibition in the college lobby at the university for students on Tuesday, 14/11/2017.
            </p>
            <a href="education/Education1.php" style="color : white; font-weight: bold;"> more Information </a>
          </article>
          <article id="ar2" class="first">
            <img src="education/ed2.jpg" >
            <h1> “Hackathon Arabia”: a youth competition for developing applications and games at the college of Computer and Information Sciences </h1>
            <p>
              Hackathon Arabia is a tech competition that many tech enthusiasts participate in,
              from developers to designers and individuals talented in developing and
              designing applications, games and VR technologies
            </p>
            <a href="education/Education2.php" style="color : white; font-weight: bold;"> more Information </a>
          </article>
          <article id="ar3" class="first">
            <img src="education/ed3.jpg" >
            <h1> (FekraTech) The National Initiative for Digital Ideas and Projects at the College of Computer and Information Science. </h1>
            <p>
              King Saud University has held an introductory meeting in the college of computer and information science
              (for both male and female students) to commence the national “FekraTech”
            </p>
            <a href="education/Education3.php" style="color : white; font-weight: bold;"> more Information </a>
          </article>
          <article id="ar4" class="second">
            <img src="education/ed4.jpg" >
            <h1> KSU Conducts Symposium on Towards Smart World </h1>
            <p>
              King Saud University has recently organized 5th National Symposium entitled, ‘Towards Smart World:
              Challenges and Solutions’ at College of Computer and Information Science (CCIS).
            </p>
            <a href="education/Education4.php" style="color : white; font-weight: bold;"> more Information </a>
          </article>
          <article id="ar5" class="first">
            <img src="education/ed5.jpg" >
            <h1> CCIS Organizes KSU-QMS Workshop </h1>
            <p>
              A workshop about the quality system KSU-QMS was conducted recently under the patronage of Dean Hassan Mathkour by
              College of Computer and Information Sciences (CCIS)
            </p>
            <a href="education/Education5.php" style="color : white; font-weight: bold;"> more Information </a>
          </article>
        </section>

        <?php
          require 'Footer.php';
        ?>
