<?php
  session_start();

  $con = mysqli_connect("localhost","root","root","nnnews");
  if(mysqli_connect_errno())
      die("Error while connecting to db: ". mysqli_connect_error());
?>

<html>
  <head>
    <meta charset="utf-8">
    <title> NNNews - Sport </title>

    <link rel="stylesheet" type="text/css" href="../NNNews - Style.css?ts=<?=time()?>" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
      window.setInterval("disDate()",1000);
      function disDate(){
        var d = new Date();
        var n = d.toLocaleString();
        document.getElementById("datetime").innerHTML = n;
      }
    </script>

  </head>

  <body class="mainColor">
    <?php
    if(isset($_SESSION['userid'])){
      ?>
      <div class="signout">
        <ul> Welcome <?php echo $_SESSION['userid'] ?>
          <li> <a href="../Signout.php"> Sign out </a> </li>
        </ul>
      </div>
      <?php
    }
      else {
        ?>
        <div class="signin">
          <a href="../Signin.php"> Sign in </a>
        </div>
        <?php
      }
  ?>
    <header class="logoBack">
    <a href="../../NNNews-home.php"><img src="../logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
      <p style="display : inline;"> NNews </p>
      <p><em>New National News</em><p>
    </header>

    <div class="topnav">
      <a href="../../NNNews-home.php"> Home </a>
      <a href="../NNNews-education.php"> Education </a>
      <a href="../NNNews-technology.php"> Technology </a>
      <a href="../NNNews-travel.php"> Travel </a>
      <a href="../NNNews-sport.php"> Sport </a>

      <?php
        if(isset($_SESSION['userid'])){ // if #1
          $uid = $_SESSION['userid'];
          $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
          $res = mysqli_query($con, $Qsel);
          if(mysqli_num_rows($res) > 0){
            while($row = mysqli_fetch_assoc($res)){
              $ro = $row['role'];
            }
          }
          if($ro == "Journalist"){
            ?>
              <a href="../JNewArticle.php"> New Article </a>
              <a href="../JDraft.php"> Draft </a>
              <a href="../JMail.php"> Mail </a>
              <a href="../JPublishedArticles.php"> Published Articles </a>
            <?php
          }
          if($ro == "Editor"){
            ?>
              <a href="../EPendingArticles.php"> Pending Articles </a>
            <?php
          }
          if($ro == "Administrator"){
            ?>
              <a href="../AManageAccounts.php"> Manage Accounts </a>
            <?php
          }
        } // if #1
        ?>

    </div>

    <div class="newsBody-border">
      <h1 class="newsBody-title"> A need for speed </h1>
      <div id="newsBody" class="newsBody">
        <img src="sp4.jpg">
        <p>
          Lips turning blue, they shiver in ice baths, unable to escape. Only the cooperation of teammates solving mental puzzles and completing physical challenges
          can release them from the water's frozen grip. "For the first guys in the ice it was brutal," says John McBride, head speed coach for the US men's ski team.
          "We didn't work together as a team, we weren't communicating effectively."
          Plunging his team in ice is a technique McBride learned from US special forces and is part of his quest to take American downhillers back to the top.
          To make them ski faster, he trains the brain. And his methods are somewhat extreme.
          In the search for the next Bode Miller, McBride subjected his squad to a Navy Seal training camp, and "scared" them on a climbing expedition on one of Colorado's
          most difficult "14ers." It is all in pursuit of one goal. For all of Lindsey Vonn's success, no American man has ever won the season-long downhill crown,
          despite Miller and Phil Mahre winning World Cup overall titles.
          </p>
      </div>
    </div>

    <div class="divide">
    </div>


    <?php
      require 'SpFooter.php';
    ?>
