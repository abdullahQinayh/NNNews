<?php
  session_start();

  $con = mysqli_connect("localhost","root","root","nnnews");
  if(mysqli_connect_errno())
      die("Error while connecting to db: ". mysqli_connect_error());
?>

<html>
  <head>
    <meta charset="utf-8">
    <title> NNNews - Travel </title>

    <link rel="stylesheet" type="text/css" href="NNNews - Style.css?ts=<?=time()?>" />

    <script>
//---------------------------------------------------------------------------------
      window.setInterval("slideShow4()",3000);
      var i =2;
      function slideShow4(){
        if (i > 5) i=1;
        var pic = document.getElementById("slideImg");
        pic.setAttribute("src","travel/tr"+i+".jpg");
        i++;
      }

      window.setInterval("disDate()",1000);
      function disDate(){
        var d = new Date();
          var n = d.toLocaleString();
          document.getElementById("datetime").innerHTML = n;
      }

      function menuBar() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
          x.className += " responsive";
        } else {
          x.className = "topnav";
        }
      }
//---------------------------------------------------------------------------------
    </script>

  </head>

  <body class="mainColor">
    <?php
    if(isset($_SESSION['userid'])){
      ?>
      <div class="signout">
        <ul> Welcome <?php echo $_SESSION['userid'] ?>
          <li> <a href="Signout.php"> Sign out </a> </li>
        </ul>
      </div>
      <?php
    }
      else {
        ?>
        <div class="signin">
          <a href="Signin.php"> Sign in </a>
        </div>
        <?php
      }
  ?>
    <header class="logoBack">
    <a href="../NNNews-home.php"><img src="logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
      <p style="display : inline;"> NNews </p>
      <p><em>New National News</em><p>
    </header>

    <div class="topnav" id="myTopnav">
      <a href="../NNNews-home.php"> Home </a>
      <a href="NNNews-education.php"> Education </a>
      <a href="NNNews-technology.php"> Technology </a>
      <a href="NNNews-travel.php" class="active"> Travel </a>
      <a href="NNNews-sport.php"> Sport </a>

      <?php
        if(isset($_SESSION['userid'])){ // if #1
          $uid = $_SESSION['userid'];
          $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
          $res = mysqli_query($con, $Qsel);
          $ro = null;
          if(mysqli_num_rows($res)==1){
            while($row = mysqli_fetch_assoc($res)){
              $ro = $row['role'];
            }
          }
          if($ro == "Journalist"){
            ?>
            <div class="dropdown">
              <button class="dropbtn">Menu</button>
              <div class="dropdown-content" id="myDropdown">
                <a href="JNewArticle.php"> New Article </a>
                <a href="JDraft.php"> Draft </a>
                <a href="JMail.php"> Mail </a>
                <a href="JPublishedArticles.php"> Published Articles </a>
              </div>
            </div>
            <?php
          }
          if($ro == "Editor"){
            ?>
              <a href="EPendingArticles.php"> Pending Articles </a>
            <?php
          }
          if($ro == "Administrator"){
            ?>
              <a href="AManageAccounts.php"> Manage Accounts </a>
            <?php
          }
        } // if #1
        ?>
        <a href="javascript:void(0);" style="font-size:15pt;" class="icon" onclick="menuBar()">&#9776;</a>
    </div>


    <section id="mainPhoto" class="slideShow">
      <img id="slideImg" src="travel/tr1.jpg">
    </section>

    <section id="news" class="news-tr">
      <h1> <em> Travel </em> </h1>
      <article id="ar1" class="first">
        <img src="travel/tr1.jpg" >
        <h1> London hotel suite on sale for $14 million </h1>
        <p> (CNN) — Got a spare $14 million lying around that you're wondering what to do with?
          If you're in the market for a new luxury pad, you could splash the cash on a 3,703 square
          foot hotel suite at 10 Whitehall Place, adjacent to the five-star Corinthia Hotel in London.
        </p>
        <a href="travel/Travel1.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar2" class="first">
        <img src="travel/tr2.jpg" >
        <h1> Flight Passengers Were Stranded for Days in Freezing Siberia </h1>
        <p>
          Passengers on an Air France flight traveling from Paris to Shanghai were left
          stranded in freezing Siberia for three days this week after their plane was forced
          to make an emergency landing and their replacement plane suffered a technical issue.
        </p>
        <a href="travel/Travel2.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar3" class="first">
        <img src="travel/tr3.jpg" >
        <h1> Opulence goes low: China opens luxury hotel in quarry </h1>
        <p>
          A hotel development sunk into a disused quarry in China opened its doors Thursday to deep-pocketed clientele.
          Preventing the 88-meter-deep (290 feet) pit from flooding was among the chief challenges for engineers working on the
          swanky 336-room InterContinental Shanghai Wonderland — part of a $288 million development that also includes a theme park.
        </p>
        <a href="travel/Travel3.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar4" class="second">
        <img src="travel/tr4.jpg" >
        <h1> Opulence goes low: China opens luxury hotel in quarry </h1>
        <p>
          Andhra Pradesh Tourism recently launched a new initiative of offering free scuba diving training. It is one-of-a-kind
          initiative launched by any tourism department. So far, 480 applications have been received, and the first batch of 10
          participants was taken near Mangamaripeta Beach to impart training on scuba diving.
        </p>
        <a href="travel/Travel4.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar5" class="first">
        <img src="travel/tr5.jpg" >
        <h1> A 2,000-km-long underwater rail will connect Mumbai to the UAE very soon! </h1>
        <p>
          Seems like the UAE is running high on technologies these days! News has it that the UAE is planning to build a 2,000-km-long
          underwater rail that will connect Mumbai to Fujairah city in the UAE, Middle East. The news came to light during the UAE-India
          Conclave organised in Abu Dhabi.
        </p>
        <a href="travel/Travel5.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
    </section>

    <?php
      require 'Footer.php';
    ?>
