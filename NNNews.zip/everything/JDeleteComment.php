<?php

  $con = mysqli_connect("localhost","root","root","NNNews");
  $id = $_GET['id'];
  $query = " DELETE FROM comments WHERE comment_id = '".$id."' ";
  $result = mysqli_query($con,$query);

  if($result){
    header('Location:JMail.php?success=COMMENT DELETED SUCCESSFULLY!');
  } else {
    header('Location:JMail.php?error=ERROR DELETING COMMENT!');
  }




?>
