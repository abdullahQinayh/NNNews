<?php

    session_start();
    $con = mysqli_connect("localhost","root","root","nnnews");

    $query = " UPDATE articles SET status = 2 WHERE article_id = '".$_GET['id']."' ";
    $result = mysqli_query($con,$query);
    if($result){
      header('Location:EPendingArticles.php?success=ARTICLE POSTED SUCCESSFULLY!');
    } else {
      header('Location:EPendingArticles.php?error=ERROR POSTING ARTICLE!');
    }



?>
