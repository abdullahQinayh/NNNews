<?php

  $con = mysqli_connect("localhost","root","root","NNNews");
  $user = $_GET['user'];
  $query = " DELETE FROM users WHERE username = '".$user."' ";
  $result = mysqli_query($con,$query);

  if($result){
    header('Location:AManageAccounts.php?success=USER DELETED SUCCESSFULLY!');
  } else {
    header('Location:AManageAccounts.php?error=ERROR DELETING USER!');
  }




?>
