<section id="summary" class="shortcut">
  <div>
    <a href="NNNews-education.php" class="p">Education</a>
    <a href="NNNews-education.php"><img src="education/edu2.jpg"></a>
  </div>
  <div>
    <a href="NNNews-technology.php" class="p">Technology</a>
    <a href="NNNews-technology.php"><img src="technology/tech2.jpg"></a>
  </div>
  <div>
    <a href="NNNews-travel.php" class="p">Travel</a>
    <a href="NNNews-travel.php"><img src="travel/travel2.jpg"></a>
  </div>
  <div>
    <a href="NNNews-sort.php" class="p">Sport</a>
    <a href="NNNews-sport.php"><img src="sport/sport1.jpg"></a>
  </div>
</section>

<footer class="foot">
  <img src="twitter.png">
  <img src="youtube.png">
  <img src="facebook.png">
  <img src="google-plus.png">
</footer>

<p>Date/Time: <span id="datetime"></span></p>


</body>
</html>
