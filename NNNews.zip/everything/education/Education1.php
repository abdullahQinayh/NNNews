<?php
  session_start();

  $con = mysqli_connect("localhost","root","root","nnnews");
  if(mysqli_connect_errno())
      die("Error while connecting to db: ". mysqli_connect_error());
?>

<html>
  <head>
    <meta charset="utf-8">
    <title> NNNews - Education </title>

    <link rel="stylesheet" type="text/css" href="../NNNews - Style.css?ts=<?=time()?>" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script>
      window.setInterval("disDate()",1000);
      function disDate(){
        var d = new Date();
        var n = d.toLocaleString();
        document.getElementById("datetime").innerHTML = n;
      }
    </script>

  </head>

  <body class="mainColor">
    <?php
    if(isset($_SESSION['userid'])){
      ?>
      <div class="signout">
        <ul> Welcome <?php echo $_SESSION['userid'] ?>
          <li> <a href="../Signout.php"> Sign out </a> </li>
        </ul>
      </div>
      <?php
    }
      else {
        ?>
        <div class="signin">
          <a href="../Signin.php"> Sign in </a>
        </div>
        <?php
      }
  ?>
    <header class="logoBack">
    <a href="../../NNNews-home.php"><img src="../logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
      <p style="display : inline;"> NNews </p>
      <p><em>New National News</em><p>
    </header>

    <div class="topnav">
      <a href="../../NNNews-home.php"> Home </a>
      <a href="../NNNews-education.php"> Education </a>
      <a href="../NNNews-technology.php"> Technology </a>
      <a href="../NNNews-travel.php"> Travel </a>
      <a href="../NNNews-sport.php"> Sport </a>

      <?php
        if(isset($_SESSION['userid'])){ // if #1
          $uid = $_SESSION['userid'];
          $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
          $res = mysqli_query($con, $Qsel);
          if(mysqli_num_rows($res) > 0){
            while($row = mysqli_fetch_assoc($res)){
              $ro = $row['role'];
            }
          }
          if($ro == "Journalist"){
            ?>
              <a href="../JNewArticle.php"> New Article </a>
              <a href="../JDraft.php"> Draft </a>
              <a href="../JMail.php"> Mail </a>
              <a href="../JPublishedArticles.php"> Published Articles </a>
            <?php
          }
          if($ro == "Editor"){
            ?>
              <a href="../EPendingArticles.php"> Pending Articles </a>
            <?php
          }
          if($ro == "Administrator"){
            ?>
              <a href="../AManageAccounts.php"> Manage Accounts </a>
            <?php
          }
        } // if #1
        ?>

    </div>

    <div class="newsBody-border">
      <h1 class="newsBody-title"> CCIS Practical Training Day </h1>
      <div id="newsBody" class="newsBody">
        <img src="ed1.jpg">
        <p>
            The Practical Training Committee at the College of Computer and Information Sciences (CCIS) at King Saud University organized the "CCIS Practical
            Training Day" and its accompanying exhibition in the college lobby at the university for students on Tuesday, 14/11/2017.  The event aims to highlight
            the achievements of female students in practical training, and transfer their experiences to their colleagues in addition to create a future training
            opportunities, and strengthening the links with the training organizations in the public and private sectors and taking their impressions of the outputs
            of the college and their technical needs into consideration.
          </p>
      </div>
    </div>

    <div class="divide">
    </div>


    <?php
      require 'EdFooter.php';
    ?>
