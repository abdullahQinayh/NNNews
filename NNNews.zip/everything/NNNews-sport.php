<?php
  session_start();

  $con = mysqli_connect("localhost","root","root","nnnews");
  if(mysqli_connect_errno())
      die("Error while connecting to db: ". mysqli_connect_error());
?>

<html>
  <head>
    <meta charset="utf-8">
    <title> NNNews - Sport </title>

    <link rel="stylesheet" type="text/css" href="NNNews - Style.css?ts=<?=time()?>" />
    <script>
//---------------------------------------------------------------------------------
      window.setInterval("slideShow4()",3000);
      var i =2;
      function slideShow4(){
        if (i > 5) i=1;
        var pic = document.getElementById("slideImg");
        pic.setAttribute("src","sport/sp"+i+".jpg");
        i++;
      }

      window.setInterval("disDate()",1000);
      function disDate(){
        var d = new Date();
          var n = d.toLocaleString();
          document.getElementById("datetime").innerHTML = n;
      }

      function menuBar() {
        var x = document.getElementById("myTopnav");
        if (x.className === "topnav") {
          x.className += " responsive";
        } else {
          x.className = "topnav";
        }
      }
//---------------------------------------------------------------------------------
    </script>

  </head>

  <body class="mainColor">
    <?php
    if(isset($_SESSION['userid'])){
      ?>
      <div class="signout">
        <ul> Welcome <?php echo $_SESSION['userid'] ?>
          <li> <a href="Signout.php"> Sign out </a> </li>
        </ul>
      </div>
      <?php
    }
      else {
        ?>
        <div class="signin">
          <a href="Signin.php"> Sign in </a>
        </div>
        <?php
      }
  ?>
    <header class="logoBack">
    <a href="../NNNews-home.php"><img src="logo2.png" alt="NNNews logo" width="100px" height="100px"></a>
      <p style="display : inline;"> NNews </p>
      <p><em>New National News</em><p>
    </header>

    <div class="topnav" id="myTopnav">
      <a href="../NNNews-home.php"> Home </a>
      <a href="NNNews-education.php"> Education </a>
      <a href="NNNews-technology.php"> Technology </a>
      <a href="NNNews-travel.php"> Travel </a>
      <a href="NNNews-sport.php" class="active"> Sport </a>

      <?php
        if(isset($_SESSION['userid'])){ // if #1
          $uid = $_SESSION['userid'];
          $Qsel = "SELECT * FROM users WHERE username = '".$uid."'";
          $res = mysqli_query($con, $Qsel);
          $ro = null;
          if(mysqli_num_rows($res)==1){
            while($row = mysqli_fetch_assoc($res)){
              $ro = $row['role'];
            }
          }
          if($ro == "Journalist"){
            ?>
            <div class="dropdown">
              <button class="dropbtn">Menu</button>
              <div class="dropdown-content" id="myDropdown">
                <a href="JNewArticle.php"> New Article </a>
                <a href="JDraft.php"> Draft </a>
                <a href="JMail.php"> Mail </a>
                <a href="JPublishedArticles.php"> Published Articles </a>
              </div>
            </div>
            <?php
          }
          if($ro == "Editor"){
            ?>
              <a href="EPendingArticles.php"> Pending Articles </a>
            <?php
          }
          if($ro == "Administrator"){
            ?>
              <a href="AManageAccounts.php"> Manage Accounts </a>
            <?php
          }
        } // if #1
        ?>
        <a href="javascript:void(0);" style="font-size:15pt;" class="icon" onclick="menuBar()">&#9776;</a>
    </div>


    <section id="mainPhoto" class="slideShow">
      <img id="slideImg" src="sport/sp1.jpg">
    </section>

    <section id="news" class="news">
      <h1> <em> Sport </em> </h1>
      <article id="ar1" class="first">
        <img src="sport/sp1.jpg" >
        <h1> No reason' the USA can't win the World Cup </h1>
        <p>
          Christian Pulisic is considered one of the most exciting prospects in world football and has become
          a beacon of hope for the United States national team.
        </p>
        <a href="sport/Sport1.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar2" class="first">
        <img src="sport/sp2.jpg" >
        <h1> Rebuilding the USA </h1>
        <p>
          Pulisic is very much at the heart of the rebuilding process and feels a responsibility to lead from the front --
          although this isn't something that necessarily comes naturally to him.
        </p>
        <a href="sport/Sport2.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar3" class="first">
        <img src="sport/sp3.jpg" >
        <h1> Making it in Germany </h1>
        <p>
          Pulisic's journey to the top of the game has been a tough one. It's also been an unusual one.
          The attacking midfielder moved to Germany to join Borussia Dortmund's youth academy in 2015 and, just a year later, made is first-team debut.
        </p>
        <a href="sport/Sport3.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar4" class="second">
        <img src="sport/sp4.jpg" >
        <h1> A need for speed </h1>
        <p>
          Lips turning blue, they shiver in ice baths, unable to escape. Only the cooperation of teammates solving mental puzzles and completing physical
          challenges can release them from the water's frozen grip.
        </p>
        <a href="sport/Sport4.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
      <article id="ar5" class="first">
        <img src="sport/sp5.jpg" >
        <h1> -- </h1>
        <p>
          She may have it all her own way on the racetrack, but Australian super mare Winx has been joined by Cracksman at the head of the Longines World's
          Best Racehorse Rankings.
        </p>
        <a href="sport/Sport5.php" style="color : white; font-weight: bold;"> more Information </a>
      </article>
    </section>

    <?php
      require 'Footer.php';
    ?>
